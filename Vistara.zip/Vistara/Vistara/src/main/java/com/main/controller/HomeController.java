package com.main.controller;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.main.Model.MMT;
import com.main.Model.VistaraCom;
import com.main.servicei.Servicei;




@RestController
public class HomeController {
	
	
	@Autowired
	Servicei ser;
	
	
	@RequestMapping("/save/{from1}/{to1}")
	public MMT[] savedata(@PathVariable("from1") String from1 , @PathVariable("to1") String to1)
	{
		MMT a=new MMT();
		
		a.setSrno(01);
		a.setName("Vistara");
		a.setDate("01/mar/2023");
		a.setFrom1("delhi");
		a.setTo1("mumbai");
		a.setPrice(3652.36);
		
		MMT a1=new MMT();
		
		a1.setSrno(02);
		a1.setName("Vistara");
		a1.setDate("21/jun/2023");
		a1.setFrom1("delhi");
		a1.setTo1("goa");
		a1.setPrice(8652.36);
		
		MMT a2=new MMT();
		
		a2.setSrno(99);
		a2.setName("Vistara");
		a2.setDate("01/sep/2023");
		a2.setFrom1("delhi");
		a2.setTo1("mumbai");
		a2.setPrice(7852.36);
		
		
		MMT a3=new MMT();
		
		a3.setSrno(56);
		a3.setName("Vistara");
		a3.setDate("01/oct/2023");
		a3.setFrom1("delhi");
		a3.setTo1("mumbai");
		a3.setPrice(5000.36);
		
		
	
		

		MMT m[]=new MMT[4];
		m[0]=a;
		m[1]=a1;
		m[2]=a2;
		m[3]=a3;
	
	
		for(MMT i:m)
		{
			if(i.getFrom1().equals(from1) && i.getTo1().equals(to1))
			{
				ser.savedata(i);	
			}
		}
		
		
		
		return m;
	}
}
