package com.main.servicei;

import com.main.Model.MMT;

public interface Servicei {

	void savedata(MMT v);

}
