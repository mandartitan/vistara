package com.main.serviceimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.main.Model.MMT;
import com.main.Repoi.HomeRepoi;
import com.main.servicei.Servicei;


@Service
public class Serviceimpl implements Servicei {

	@Autowired
	HomeRepoi hr;
	
	@Override
	public void savedata(MMT v) {
		hr.save(v);
		
	}

}
