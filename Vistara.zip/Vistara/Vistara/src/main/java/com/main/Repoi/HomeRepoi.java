package com.main.Repoi;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.main.Model.MMT;


@Repository
public interface HomeRepoi  extends JpaRepository<MMT, Integer>{

}
