package com.main.Model;

import java.util.Comparator;

public class VistaraCom implements Comparator<MMT> {

	@Override
	public int compare(MMT o1, MMT o2) {
		// TODO Auto-generated method stub
		return (int) (o1.getPrice() - o2.getPrice());
	}

}
